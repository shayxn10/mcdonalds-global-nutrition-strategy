import { createFileRoute } from "@tanstack/react-router";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend } from "recharts";
import { PageHeader, InsightPanel, SectionCard, FlagBadge } from "@/components/dash/Primitives";
import { mccafeShare, mccafeSugar, COLORS } from "@/data/mcd";
import mccafeLogo from "@/assets/mccafe-logo.png.asset.json";
import starbucksLogo from "@/assets/starbucks-logo.png.asset.json";

export const Route = createFileRoute("/mccafe")({
  head: () => ({ meta: [{ title: "McCafé Strategic Layer" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 07 · Strategic Layer"
        title="McCafé is a global strategic growth engine"
        subtitle="Beverage led, high margin, and Starbucks adjacent. McCafé is McDonald's transformation vector from QSR into a hybrid café platform."
      />

      {/* Brand hero banner */}
      <div className="rounded-2xl overflow-hidden relative" style={{ background: "linear-gradient(135deg, #2b1810 0%, #4a2818 60%, #6b3a1f 100%)" }}>
        <div className="grid md:grid-cols-[1.2fr_1fr] gap-0 items-center">
          <div className="p-10 text-white">
            <img src={mccafeLogo.url} alt="McCafé" className="h-16 mb-5 bg-white rounded-md p-2 inline-block" />
            <h2 className="text-3xl font-bold leading-tight mb-3">A separate business line inside the arches</h2>
            <p className="text-white/75 max-w-lg leading-relaxed">McCafé operates with café economics, not QSR economics. Higher gross margin, longer dwell time, morning ritual capture. It is McDonald's quiet pivot into the premium coffee occasion without rebranding a single store.</p>
            <div className="flex gap-6 mt-6 pt-6 border-t border-white/15">
              <div><div className="text-2xl font-bold text-[var(--mcd-yellow)]">27%</div><div className="text-[11px] uppercase tracking-wider text-white/60">India menu share</div></div>
              <div><div className="text-2xl font-bold text-[var(--mcd-yellow)]">11%</div><div className="text-[11px] uppercase tracking-wider text-white/60">USA menu share</div></div>
              <div><div className="text-2xl font-bold text-[var(--mcd-yellow)]">70 to 80%</div><div className="text-[11px] uppercase tracking-wider text-white/60">Beverage gross margin</div></div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-1 p-1">
            {[
              "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=400&auto=format&fit=crop",
              "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=400&auto=format&fit=crop",
              "https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=400&auto=format&fit=crop",
              "https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=400&auto=format&fit=crop",
              "https://images.unsplash.com/photo-1534778101976-62847782c213?w=400&auto=format&fit=crop",
              "https://images.unsplash.com/photo-1517959105821-eaf2591984ca?w=400&auto=format&fit=crop",
            ].map((src, i) => (
              <img key={i} src={src} alt="" className="w-full h-32 object-cover rounded-sm" loading="lazy" />
            ))}
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <SectionCard title="Menu share · India" subtitle="McCafé is 27% of items" action={<FlagBadge country="India" />}>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={mccafeShare.india} dataKey="value" innerRadius={55} outerRadius={100} paddingAngle={2}>
                {mccafeShare.india.map((d, i) => <Cell key={i} fill={d.fill} />)}
              </Pie>
              <Tooltip formatter={(v: number) => `${v}%`} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-3 text-xs justify-center">
            {mccafeShare.india.map((d) => (
              <div key={d.name} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm" style={{ background: d.fill }} />{d.name}
              </div>
            ))}
          </div>
        </SectionCard>
        <SectionCard title="Menu share · USA" subtitle="McCafé is 11% of items" action={<FlagBadge country="USA" />}>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={mccafeShare.usa} dataKey="value" innerRadius={55} outerRadius={100} paddingAngle={2}>
                {mccafeShare.usa.map((d, i) => <Cell key={i} fill={d.fill} />)}
              </Pie>
              <Tooltip formatter={(v: number) => `${v}%`} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-3 text-xs justify-center">
            {mccafeShare.usa.map((d) => (
              <div key={d.name} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm" style={{ background: d.fill }} />{d.name}
              </div>
            ))}
          </div>
        </SectionCard>
        <div className="space-y-4">
          <InsightPanel title="McCafé is the margin play">
            <p>Beverages carry the highest gross margin in QSR, typically 70 to 80 percent versus 30 to 40 percent for food. McCafé's 27 percent menu share in India is a deliberate margin lift inside a price sensitive market.</p>
          </InsightPanel>
          <InsightPanel title="The Starbucks flank">
            <div className="flex items-start gap-3">
              <img src={starbucksLogo.url} alt="Starbucks" className="w-12 h-12 object-contain shrink-0" />
              <p>McCafé competes indirectly with Starbucks and Costa. It extends dwell time, builds the morning routine, and captures the premium coffee occasion without rebranding the store.</p>
            </div>
          </InsightPanel>
        </div>
      </div>

      <SectionCard title="Sugar intensity by category" subtitle="McCafé frappés carry 6 to 10 times the sugar of mains">
        <ResponsiveContainer width="100%" height={320}>
          <BarChart data={mccafeSugar}>
            <CartesianGrid stroke="#eee" strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="category" tick={{ fontSize: 11, fill: "#666" }} />
            <YAxis tick={{ fontSize: 11, fill: "#666" }} label={{ value: "Sugar (g)", angle: -90, position: "insideLeft", style: { fontSize: 11, fill: "#666" } }} />
            <Tooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} />
            <Legend iconType="circle" />
            <Bar dataKey="India" fill={COLORS.india} radius={[6, 6, 0, 0]} />
            <Bar dataKey="USA" fill={COLORS.usa} radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
        <InsightPanel title="So What">
          <ul className="list-disc pl-5 space-y-1">
            <li>Sugar load in both markets is concentrated inside the McCafé and dessert beverage line, not the food menu.</li>
            <li>A single large USA frappé delivers more sugar than an entire combo meal of mains.</li>
            <li>Reformulating two SKUs (frappé base, shake base) would move the global sugar number more than any food change.</li>
          </ul>
        </InsightPanel>
      </SectionCard>

      <div className="card-elevated p-6 bg-gradient-to-br from-[#FFF9E6] to-white border-l-4 border-[var(--mcd-yellow)]">
        <div className="text-[11px] uppercase tracking-[0.18em] font-bold text-[var(--mcd-red)] mb-2">Strategic conclusion</div>
        <h3 className="text-xl font-bold mb-2">McDonald's is quietly becoming a café chain</h3>
        <p className="text-foreground/75">McCafé is not a side bet. It is the long arc repositioning of a global burger brand into a hybrid food and beverage platform. India is the testbed. The USA is the defensive front line.</p>
      </div>
    </div>
  );
}
