import { createFileRoute } from "@tanstack/react-router";
import { Fragment } from "react";
import { PageHeader, InsightPanel, SectionCard } from "@/components/dash/Primitives";
import { calorieBox, correlationMatrix, COLORS } from "@/data/mcd";

export const Route = createFileRoute("/nutrition")({
  head: () => ({ meta: [{ title: "Nutrition Architecture · India vs USA" }] }),
  component: Page,
});

function BoxPlot() {
  const max = 2000;
  const w = 600, h = 220, pad = 60;
  const scaleX = (v: number) => pad + (v / max) * (w - pad * 2);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full">
      {[0, 500, 1000, 1500, 2000].map((t) => (
        <g key={t}>
          <line x1={scaleX(t)} x2={scaleX(t)} y1={20} y2={h - 30} stroke="#eee" />
          <text x={scaleX(t)} y={h - 12} fontSize="10" fill="#666" textAnchor="middle">{t}</text>
        </g>
      ))}
      {calorieBox.map((b, i) => {
        const y = 60 + i * 80;
        const color = b.country === "India" ? COLORS.india : COLORS.usa;
        return (
          <g key={b.country}>
            <line x1={scaleX(b.min)} x2={scaleX(b.max)} y1={y} y2={y} stroke={color} strokeWidth={2} />
            <line x1={scaleX(b.min)} x2={scaleX(b.min)} y1={y - 10} y2={y + 10} stroke={color} strokeWidth={2} />
            <line x1={scaleX(b.max)} x2={scaleX(b.max)} y1={y - 10} y2={y + 10} stroke={color} strokeWidth={2} />
            <rect x={scaleX(b.q1)} y={y - 18} width={scaleX(b.q3) - scaleX(b.q1)} height={36} fill={color} fillOpacity={0.18} stroke={color} strokeWidth={2} rx={4} />
            <line x1={scaleX(b.median)} x2={scaleX(b.median)} y1={y - 18} y2={y + 18} stroke={color} strokeWidth={3} />
            <text x={20} y={y + 4} fontSize="12" fontWeight="600" fill="#333">{b.country}</text>
          </g>
        );
      })}
      <text x={w / 2} y={14} fontSize="11" fill="#666" textAnchor="middle">Calories (kcal) per item</text>
    </svg>
  );
}

function Heatmap({ data, label, color }: { data: number[][]; label: string; color: string }) {
  const m = correlationMatrix.metrics;
  return (
    <div>
      <div className="text-xs font-semibold mb-2 text-center" style={{ color }}>{label}</div>
      <div className="grid" style={{ gridTemplateColumns: `60px repeat(${m.length}, 1fr)` }}>
        <div />
        {m.map((x) => <div key={x} className="text-[10px] text-center font-semibold py-1">{x}</div>)}
        {data.map((row, i) => (
          <Fragment key={`r${i}`}>
            <div className="text-[10px] font-semibold flex items-center justify-end pr-2">{m[i]}</div>
            {row.map((v, j) => {
              const intensity = Math.abs(v);
              const bg = v >= 0
                ? `rgba(218,41,28,${0.15 + intensity * 0.65})`
                : `rgba(0,40,104,${0.15 + intensity * 0.65})`;
              return (
                <div key={j} className="aspect-square flex items-center justify-center text-[11px] font-semibold rounded-sm m-0.5" style={{ background: bg, color: intensity > 0.5 ? "#fff" : "#333" }}>
                  {v.toFixed(2)}
                </div>
              );
            })}
          </Fragment>
        ))}
      </div>
    </div>
  );
}

function Page() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 04 · Nutrition Architecture"
        title="The USA menu is calorie dense, the India menu is more variable and culturally constrained"
        subtitle="Distribution shape and metric correlations expose the structural logic of each market's menu."
      />

      <SectionCard title="Calorie distribution by country" subtitle="Minimum, Q1, median, Q3, and maximum per item">
        <BoxPlot />
        <InsightPanel title="So What">
          <ul className="list-disc pl-5 space-y-1">
            <li>USA median calories sit roughly 150 kcal above the Indian median.</li>
            <li>USA tail extends to 1,880 kcal, driven by breakfast platforms and bulk nugget orders.</li>
            <li>India's distribution is tighter, reflecting a smaller assortment and a vegetarian first portfolio.</li>
          </ul>
        </InsightPanel>
      </SectionCard>

      <div className="grid lg:grid-cols-3 gap-6">
        <SectionCard title="Correlation matrix · India" subtitle="Pearson across four macronutrients">
          <Heatmap data={correlationMatrix.india} label="India" color={COLORS.india} />
        </SectionCard>
        <SectionCard title="Correlation matrix · USA" subtitle="Pearson across four macronutrients">
          <Heatmap data={correlationMatrix.usa} label="USA" color={COLORS.usa} />
        </SectionCard>
        <div className="space-y-4">
          <InsightPanel title="The protein and calorie linkage is tighter in the USA">
            <p>The USA correlation of 0.81 versus India's 0.62 reflects a standardized meat portion architecture. India's looser coupling comes from paneer, which is high in fat but moderate in protein, breaking the link.</p>
          </InsightPanel>
          <InsightPanel title="Sugar lives in beverages in both markets">
            <p>Near zero sugar to sodium correlation in both markets confirms that the sugar load is beverage driven, sitting inside shakes, frappés, and sodas rather than food.</p>
          </InsightPanel>
        </div>
      </div>
    </div>
  );
}
