import { createFileRoute } from "@tanstack/react-router";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, ScatterChart, Scatter, ZAxis, Legend } from "recharts";
import { PageHeader, InsightPanel, SectionCard } from "@/components/dash/Primitives";
import { topRiskItems, sodiumVsCalories, COLORS } from "@/data/mcd";

export const Route = createFileRoute("/risk")({
  head: () => ({ meta: [{ title: "Risk & Health Analysis" }] }),
  component: Page,
});

const itemThumbs: Record<string, string> = {
  "McSpicy Premium Chicken": "https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=120&auto=format&fit=crop",
  "Maharaja Mac Chicken": "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=120&auto=format&fit=crop",
  "Frappé Mocha Large": "https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=120&auto=format&fit=crop",
  "Big Breakfast w/ Hotcakes": "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=120&auto=format&fit=crop",
  "Chicken McNuggets 40pc": "https://images.unsplash.com/photo-1562967914-608f82629710?w=120&auto=format&fit=crop",
  "McChicken Bacon Premium": "https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=120&auto=format&fit=crop",
  "Cold Coffee (McCafé)": "https://images.unsplash.com/photo-1517959105821-eaf2591984ca?w=120&auto=format&fit=crop",
  "McSpicy Paneer": "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=120&auto=format&fit=crop",
  "Double Quarter Pounder": "https://images.unsplash.com/photo-1550317138-10000687a72b?w=120&auto=format&fit=crop",
  "Chocolate Shake Large": "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=120&auto=format&fit=crop",
};

function Page() {
  const sorted = [...topRiskItems].sort((a, b) => b.risk - a.risk);
  const india = sodiumVsCalories.filter(d => d.country === "India");
  const usa = sodiumVsCalories.filter(d => d.country === "USA");
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 08 · Risk & Health"
        title="A few categories drive disproportionate health risk"
        subtitle="Risk is a function of sugar, sodium, saturated fat, and trans fat. The top items are not random. They cluster around fried chicken and dessert beverages."
      />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SectionCard title="Top 10 risk items across India and the USA" subtitle="Composite risk score on a 0 to 100 scale">
            <ResponsiveContainer width="100%" height={420}>
              <BarChart data={sorted} layout="vertical" margin={{ left: 30 }}>
                <CartesianGrid stroke="#eee" strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: "#666" }} />
                <YAxis type="category" dataKey="item" tick={{ fontSize: 10, fill: "#333" }} width={220} />
                <Tooltip />
                <Bar dataKey="risk" radius={[0, 6, 6, 0]}>
                  {sorted.map((d, i) => (
                    <Cell key={i} fill={d.country === "India" ? COLORS.india : COLORS.usa} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </SectionCard>
        </div>
        <div className="space-y-4">
          <InsightPanel title="Fried chicken and frappés dominate" tone="red">
            <p>McSpicy Chicken, Maharaja Mac, and Frappé Mocha sit across three different categories yet share one profile: fat and sugar density.</p>
          </InsightPanel>
          <InsightPanel title="Sugar and sodium are the primary risk drivers">
            <p>Cholesterol matters in the USA. In India, sugar from beverages and sodium from sauces do most of the structural damage.</p>
          </InsightPanel>
        </div>
      </div>

      <SectionCard title="Top risk items with visual reference" subtitle="The product, the market, and the composite risk score">
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {sorted.slice(0, 10).map((d) => (
            <div key={d.item} className="card-elevated p-3 flex gap-3 items-center">
              <img src={itemThumbs[d.item]} alt="" className="w-12 h-12 rounded-md object-cover shrink-0" loading="lazy" />
              <div className="min-w-0 flex-1">
                <div className="text-[11px] truncate font-medium">{d.item}</div>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] px-1.5 py-0.5 rounded text-white font-semibold" style={{ background: d.country === "India" ? COLORS.india : COLORS.usa }}>
                    {d.country === "India" ? "🇮🇳" : "🇺🇸"}
                  </span>
                  <span className="text-sm font-bold tabular-nums" style={{ color: COLORS.red }}>{d.risk}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>

      <SectionCard title="Sodium versus calories per item" subtitle="USA items cluster far higher on both axes">
        <ResponsiveContainer width="100%" height={360}>
          <ScatterChart>
            <CartesianGrid stroke="#eee" strokeDasharray="3 3" />
            <XAxis type="number" dataKey="calories" name="Calories" tick={{ fontSize: 11, fill: "#666" }} label={{ value: "Calories", position: "insideBottom", offset: -5, style: { fontSize: 11 } }} />
            <YAxis type="number" dataKey="sodium" name="Sodium" tick={{ fontSize: 11, fill: "#666" }} label={{ value: "Sodium (mg)", angle: -90, position: "insideLeft", style: { fontSize: 11 } }} />
            <ZAxis range={[40, 40]} />
            <Tooltip cursor={{ strokeDasharray: "3 3" }} />
            <Legend />
            <Scatter name="India" data={india} fill={COLORS.india} fillOpacity={0.6} />
            <Scatter name="USA" data={usa} fill={COLORS.usa} fillOpacity={0.6} />
          </ScatterChart>
        </ResponsiveContainer>
        <InsightPanel title="So What">
          <ul className="list-disc pl-5 space-y-1">
            <li>USA items cluster in the upper right of the chart, a calorie and sodium rich quadrant.</li>
            <li>India items sit tighter and lower, but with a persistent sodium tilt at equivalent calorie levels.</li>
            <li>The health intervention point differs by market. The USA needs calorie discipline. India needs sodium discipline.</li>
          </ul>
        </InsightPanel>
      </SectionCard>
    </div>
  );
}
