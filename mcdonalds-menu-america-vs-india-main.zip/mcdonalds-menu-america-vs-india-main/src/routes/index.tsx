import { createFileRoute } from "@tanstack/react-router";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { PageHeader, KpiCard, InsightPanel, SectionCard, FlagBadge } from "@/components/dash/Primitives";
import { kpis, nutritionCompare, COLORS } from "@/data/mcd";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Global Overview · McDonald's India vs USA" }] }),
  component: Overview,
});

function Overview() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 01 · Global Overview"
        title="McDonald's Global Menu Strategy: India versus USA"
        subtitle="How culture, competition, and market maturity shape menu architecture and nutritional identity across two of McDonald's most strategically distinct markets."
        right={<div className="flex gap-2"><FlagBadge country="India" /><FlagBadge country="USA" /></div>}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Avg Calories" value={`${kpis.india.avgCalories} / ${kpis.usa.avgCalories}`} sub="kcal · India / USA" accent="red" />
        <KpiCard label="Avg Protein" value={`${kpis.india.avgProtein} / ${kpis.usa.avgProtein} g`} sub="USA 93 percent higher" accent="yellow" />
        <KpiCard label="Avg Sugar" value={`${kpis.india.avgSugar} / ${kpis.usa.avgSugar} g`} sub="USA 3.2 times India" accent="usa" />
        <KpiCard label="Avg Sodium" value={`${kpis.india.avgSodium} / ${kpis.usa.avgSodium} mg`} sub="USA notably higher" accent="india" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SectionCard title="Nutrition profile · India vs USA" subtitle="Side by side averages across the four primary macronutrient indicators">
            <ResponsiveContainer width="100%" height={340}>
              <BarChart data={nutritionCompare} barGap={6}>
                <CartesianGrid stroke="#eee" strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="metric" tick={{ fontSize: 11, fill: "#666" }} />
                <YAxis tick={{ fontSize: 11, fill: "#666" }} />
                <Tooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} />
                <Legend iconType="circle" />
                <Bar dataKey="India" fill={COLORS.india} radius={[6, 6, 0, 0]} />
                <Bar dataKey="USA" fill={COLORS.usa} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </SectionCard>
        </div>
        <InsightPanel title="Two markets, one brand, two nutritional identities">
          <p>The USA menu is calorie dense, protein heavy, and dominated by red meat and shakes. It reflects a mature market that expects large portions.</p>
          <p>The India menu is structurally lighter but culturally constrained. It is vegetarian first, paneer led, with sugar risk concentrated inside McCafé beverages.</p>
          <p>The 47 percent calorie gap and the 3.2 times sugar gap are not accidents. They are direct reflections of competitive structure and cultural diet norms.</p>
        </InsightPanel>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { t: "Menu items analyzed", v: `${kpis.india.items + kpis.usa.items}`, s: `${kpis.india.items} India · ${kpis.usa.items} USA` },
          { t: "Pages of analysis", v: "13", s: "Strategy, nutrition, risk, culture" },
          { t: "Datasets unified", v: "3", s: "India, USA, cross country" },
        ].map((x) => (
          <div key={x.t} className="card-elevated p-5">
            <div className="text-xs text-muted-foreground uppercase tracking-wider">{x.t}</div>
            <div className="text-2xl font-bold mt-1">{x.v}</div>
            <div className="text-xs text-muted-foreground mt-1">{x.s}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
