import { createFileRoute } from "@tanstack/react-router";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { PageHeader, InsightPanel, SectionCard, FlagBadge } from "@/components/dash/Primitives";
import { usaTopCalories, usaCategoryCalories, COLORS } from "@/data/mcd";
import breakfastImg from "@/assets/mcd-breakfast.png.asset.json";

export const Route = createFileRoute("/usa-intensity")({
  head: () => ({ meta: [{ title: "USA Menu Intensity" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 06 · USA Intensity"
        title="USA menu is protein and calorie intensive"
        subtitle="Breakfast and chicken combos drive the calorie outliers. Portion size, not ingredient density, is the multiplier."
        right={<FlagBadge country="USA" />}
      />

      <div className="card-elevated overflow-hidden grid md:grid-cols-[1fr_1.1fr]">
        <img src={breakfastImg.url} alt="McDonald's USA breakfast lineup including McMuffin and hot cakes" className="w-full h-full object-cover min-h-[240px]" loading="lazy" />
        <div className="p-6">
          <div className="text-[11px] uppercase tracking-[0.18em] font-bold text-[var(--mcd-red)] mb-2">Breakfast as a calorie platform</div>
          <h3 className="text-xl font-bold mb-2">An all day breakfast strategy meets a 1,880 kcal plate</h3>
          <p className="text-sm text-foreground/75">The Big Breakfast with Hotcakes, sausage McMuffin, and hash brown stack push the breakfast daypart into top quartile calorie territory. Breakfast in the USA is not a light meal occasion. It is a full meal architecture with a dedicated supply chain.</p>
        </div>
      </div>



      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SectionCard title="Top 10 highest calorie items in the USA menu" subtitle="Outliers above 1,500 kcal are typically breakfast platforms or 40 piece nugget orders">
            <ResponsiveContainer width="100%" height={420}>
              <BarChart data={[...usaTopCalories].sort((a,b)=>b.calories-a.calories)} layout="vertical" margin={{ left: 30 }}>
                <CartesianGrid stroke="#eee" strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: "#666" }} />
                <YAxis type="category" dataKey="item" tick={{ fontSize: 10, fill: "#333" }} width={230} />
                <Tooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} />
                <Bar dataKey="calories" radius={[0, 6, 6, 0]}>
                  {usaTopCalories.map((d, i) => (
                    <Cell key={i} fill={d.calories > 1500 ? COLORS.red : d.calories > 800 ? "#FF8C42" : COLORS.yellow} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </SectionCard>
        </div>
        <div className="space-y-4">
          <InsightPanel title="Breakfast is the hidden calorie engine" tone="red">
            <p>The Big Breakfast with Hotcakes at 1,880 kcal is a single meal that already exceeds most adults' total daily energy need. Three of the top 10 items are breakfast format.</p>
          </InsightPanel>
          <InsightPanel title="Outliers are portion driven, not ingredient driven">
            <p>The 40 piece McNugget and the large shakes carry the same per piece nutrition as their smaller siblings. It is pack size, not recipe, that creates the calorie bombs.</p>
          </InsightPanel>
        </div>
      </div>

      <SectionCard title="Average calories by USA category" subtitle="Multiple categories are calorie dense, the load is not concentrated in one place">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={usaCategoryCalories}>
            <CartesianGrid stroke="#eee" strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="category" tick={{ fontSize: 11, fill: "#666" }} angle={-15} textAnchor="end" height={70} />
            <YAxis tick={{ fontSize: 11, fill: "#666" }} />
            <Tooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} />
            <Bar dataKey="avg" radius={[6, 6, 0, 0]}>
              {usaCategoryCalories.map((d, i) => (
                <Cell key={i} fill={d.avg > 500 ? COLORS.red : d.avg > 300 ? COLORS.yellow : COLORS.gray} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        <InsightPanel title="So What">
          <ul className="list-disc pl-5 space-y-1">
            <li>Smoothies, shakes, chicken, and breakfast all sit above 500 kcal on average. Risk is broad based, not single category.</li>
            <li>McCafé sits notably lower at around 312 kcal, reinforcing its role as the lighter daypart anchor in the USA.</li>
            <li>Salads and beverages stay below 250 kcal but represent a small fraction of total order mix.</li>
          </ul>
        </InsightPanel>
      </SectionCard>

    </div>
  );
}
