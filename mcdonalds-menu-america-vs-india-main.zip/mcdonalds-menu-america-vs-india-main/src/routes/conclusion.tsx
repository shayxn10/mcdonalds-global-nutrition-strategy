import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/dash/Primitives";
import { Sparkles } from "lucide-react";

export const Route = createFileRoute("/conclusion")({
  head: () => ({ meta: [{ title: "Final Strategic Conclusion" }] }),
  component: Page,
});

const pillars = [
  { t: "Menu", d: "A reflection of culture and competition. Localization in India, scale in the USA, both expressions of the same logic." },
  { t: "Nutrition", d: "An outcome of market maturity. The USA's calorie density is a feature, not a flaw. It serves the portion economics model." },
  { t: "McCafé", d: "The future growth engine. Margins, dwell time, and morning routine, all captured without rebranding the store." },
  { t: "Health tradeoff", d: "Intentional, not accidental. Risk is the price of profitability. The open question is how long that calculus holds." },
];

function Page() {
  return (
    <div className="space-y-10">
      <PageHeader
        eyebrow="Page 13 · Final Conclusion"
        title="McDonald's is evolving into a hybrid global nutrition platform"
        subtitle="Not a burger chain. Not a café. A multi market, multi daypart system that uses cultural inputs to drive standardized margin outcomes."
      />

      <div className="rounded-2xl p-10 text-white relative overflow-hidden" style={{ background: "var(--gradient-mcd)" }}>
        <div className="absolute top-4 right-4 opacity-20"><Sparkles className="w-24 h-24" /></div>
        <div className="text-[11px] uppercase tracking-[0.2em] font-semibold mb-4 text-white/80">The single insight</div>
        <h2 className="text-3xl md:text-4xl font-bold leading-tight max-w-4xl">
          McDonald's local menus look incompatible, but the underlying system is identical. <span className="text-[var(--mcd-yellow)]">Absorb culture, scale operations, monetize beverages.</span>
        </h2>
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        {pillars.map((p, i) => (
          <div key={p.t} className="card-elevated p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-md flex items-center justify-center font-bold text-white" style={{ background: "var(--mcd-red)" }}>{i + 1}</div>
              <h3 className="font-bold text-lg">{p.t}</h3>
            </div>
            <p className="text-sm text-foreground/75 leading-relaxed">{p.d}</p>
          </div>
        ))}
      </div>

      <div className="card-elevated p-8 text-center bg-gradient-to-br from-[#FFF9E6] to-white">
        <div className="text-[11px] uppercase tracking-[0.18em] text-[var(--mcd-red)] font-bold mb-3">End of analysis</div>
        <p className="text-foreground/70 max-w-2xl mx-auto">
          13 pages, 2 markets, more than 400 menu items, 1 strategic system. Compiled from indiamcd.py, usdmcd.py, and the unified usindmcd.py cross country dataset.
        </p>
      </div>

    </div>
  );
}
