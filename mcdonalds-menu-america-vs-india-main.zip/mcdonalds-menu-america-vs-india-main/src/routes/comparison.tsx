import { createFileRoute } from "@tanstack/react-router";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { PageHeader, InsightPanel, SectionCard, FlagBadge } from "@/components/dash/Primitives";
import { mirrored, fries, COLORS } from "@/data/mcd";
import friesImg from "@/assets/mcd-fries.jpg.asset.json";

export const Route = createFileRoute("/comparison")({
  head: () => ({ meta: [{ title: "Cross-Country Comparison" }] }),
  component: Page,
});

function MirrorBar() {
  const max = Math.max(...mirrored.flatMap(m => [m.India, m.USA]));
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-[1fr_auto_1fr] gap-4 items-center pb-2 border-b border-border">
        <div className="text-right text-[11px] font-semibold uppercase tracking-wider text-[var(--india)]">🇮🇳 India</div>
        <div className="w-32" />
        <div className="text-[11px] font-semibold uppercase tracking-wider text-[var(--usa)]">🇺🇸 USA</div>
      </div>
      {mirrored.map((m) => (
        <div key={m.metric} className="grid grid-cols-[1fr_auto_1fr] gap-4 items-center">
          <div className="flex justify-end">
            <div className="h-7 rounded-l-md flex items-center justify-end pr-2 text-[11px] font-semibold text-white"
              style={{ background: COLORS.india, width: `${(m.India / max) * 100}%` }}>{m.India}</div>
          </div>
          <div className="text-xs font-semibold w-32 text-center text-foreground/70">{m.metric}</div>
          <div>
            <div className="h-7 rounded-r-md flex items-center pl-2 text-[11px] font-semibold text-white"
              style={{ background: COLORS.usa, width: `${(m.USA / max) * 100}%` }}>{m.USA}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function Page() {
  const friesChart = fries.map(f => ({ name: f.size, India: f.India_cal, USA: f.USA_cal }));
  const sodiumChart = fries.map(f => ({ name: f.size, India: f.India_sodium, USA: f.USA_sodium }));
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 09 · Cross-Country"
        title="Same brand, two fundamentally different nutritional identities"
        subtitle="A mirrored view makes the structural gap immediately legible."
        right={<div className="flex gap-2"><FlagBadge country="India" /><FlagBadge country="USA" /></div>}
      />

      <SectionCard title="Mirrored nutrition · India versus USA" subtitle="Average per item across the menu">
        <MirrorBar />
        <InsightPanel title="So What">
          <ul className="list-disc pl-5 space-y-1">
            <li>The USA item is roughly 47 percent more calorie dense than the Indian item on average.</li>
            <li>Protein nearly doubles in the USA, driven by larger meat portions, not richer recipes.</li>
            <li>Sugar runs 3.2 times higher in the USA, almost entirely inside shakes and frappés.</li>
          </ul>
        </InsightPanel>
      </SectionCard>

      <div className="grid lg:grid-cols-2 gap-6">
        <SectionCard title="Fries · calories by size" subtitle="Surprisingly similar across both markets" action={<FlagBadge country="India" />}>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={friesChart}>
              <CartesianGrid stroke="#eee" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Legend iconType="circle" />
              <Bar dataKey="India" fill={COLORS.india} radius={[6,6,0,0]} />
              <Bar dataKey="USA" fill={COLORS.usa} radius={[6,6,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>
        <SectionCard title="Fries · sodium by size" subtitle="India is consistently higher, a flavor adaptation signal" action={<FlagBadge country="USA" />}>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={sodiumChart}>
              <CartesianGrid stroke="#eee" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Legend iconType="circle" />
              <Bar dataKey="India" fill={COLORS.india} radius={[6,6,0,0]} />
              <Bar dataKey="USA" fill={COLORS.usa} radius={[6,6,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>

      <div className="card-elevated overflow-hidden grid md:grid-cols-[1.1fr_1fr]">
        <div className="p-6">
          <div className="text-[11px] uppercase tracking-[0.18em] font-bold text-[var(--mcd-red)] mb-2">The fries paradox</div>
          <h3 className="text-xl font-bold mb-3">Same potato. Same oil. Different salt shaker.</h3>
          <p className="text-sm text-foreground/75 leading-relaxed mb-4">At matching portion sizes, Indian fries carry roughly 10 to 15 percent more sodium than the USA equivalent. The most globally standardized product on the menu is quietly being localized at the seasoning layer.</p>
          <InsightPanel title="So What">
            <ul className="list-disc pl-5 space-y-1">
              <li>Localization reaches all the way down to the salt shaker, not just the recipe card.</li>
              <li>India sodium drift compounds with spicier mains, lifting overall sodium intake.</li>
              <li>The fries SKU is a quiet lever for any global sodium reduction commitment.</li>
            </ul>
          </InsightPanel>
        </div>
        <img src={friesImg.url} alt="McDonald's french fries lineup" className="w-full h-full object-cover min-h-[280px]" loading="lazy" />
      </div>
    </div>
  );
}
