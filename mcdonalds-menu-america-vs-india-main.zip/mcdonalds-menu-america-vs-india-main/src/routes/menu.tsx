import { createFileRoute } from "@tanstack/react-router";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { PageHeader, InsightPanel, SectionCard } from "@/components/dash/Primitives";
import { categoryDist, COLORS } from "@/data/mcd";
import indiaBurgers from "@/assets/mcd-india-burgers.png.asset.json";

export const Route = createFileRoute("/menu")({
  head: () => ({ meta: [{ title: "Menu Composition · India vs USA" }] }),
  component: Page,
});

const categoryThumbs: Record<string, string> = {
  "Breakfast": "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=200&auto=format&fit=crop",
  "Main (Burger/Beef/Chicken)": "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=200&auto=format&fit=crop",
  "McCafé / Coffee": "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=200&auto=format&fit=crop",
  "Desserts": "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=200&auto=format&fit=crop",
  "Beverages / Shakes": "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=200&auto=format&fit=crop",
  "Other / Sides": "https://images.unsplash.com/photo-1576107232684-1279f390859f?w=200&auto=format&fit=crop",
};

function Page() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 03 · Menu Architecture"
        title="Menu architecture differs fundamentally by culture"
        subtitle="India over indexes on McCafé and localized vegetarian items. The USA's spine is meat based mains and breakfast."
      />

      <div className="card-elevated overflow-hidden grid md:grid-cols-[1.1fr_1fr]">
        <div className="p-6">
          <div className="text-[11px] uppercase tracking-[0.18em] font-bold text-[var(--india)] mb-2">Flavours of India</div>
          <h3 className="text-xl font-bold mb-2">A menu redesigned around a vegetarian first palate</h3>
          <p className="text-sm text-foreground/75">McAloo Tikki, McSpicy Paneer, and Maharaja Mac Chicken anchor the Indian core. Beef is absent. Pork is absent. The protein wall is rebuilt around chicken, paneer, and potato, layered with spice.</p>
        </div>
        <img src={indiaBurgers.url} alt="McDonald's Flavours of India burger lineup" className="w-full h-full object-cover min-h-[220px]" loading="lazy" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SectionCard title="Item count by category" subtitle="Number of distinct menu items per category">
            <ResponsiveContainer width="100%" height={380}>
              <BarChart data={categoryDist} layout="vertical" margin={{ left: 80 }}>
                <CartesianGrid stroke="#eee" strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: "#666" }} />
                <YAxis type="category" dataKey="category" tick={{ fontSize: 11, fill: "#666" }} width={170} />
                <Tooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} />
                <Legend iconType="circle" />
                <Bar dataKey="India" fill={COLORS.india} radius={[0, 6, 6, 0]} />
                <Bar dataKey="USA" fill={COLORS.usa} radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </SectionCard>
        </div>
        <div className="space-y-4">
          <InsightPanel title="India: McCafé plus vegetarian density">
            <p>27 percent of India's menu is McCafé, a beverage led structure that masks the relatively small footprint of mains. Paneer, aloo, and spicy wraps replace the global beef anchor.</p>
          </InsightPanel>
          <InsightPanel title="USA: a meat mains spine" tone="blue">
            <p>The USA carries 95 distinct main items versus India's 28. The menu is built around a deep segmented protein wall of beef, chicken, and fish, supported by industrial scale breakfast.</p>
          </InsightPanel>
        </div>
      </div>

      <SectionCard title="Category footprint at a glance" subtitle="A visual snapshot of how each menu pillar is staffed in both markets">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {categoryDist.map((c) => (
            <div key={c.category} className="card-elevated p-4 flex gap-3 items-center">
              <img src={categoryThumbs[c.category]} alt="" className="w-14 h-14 rounded-md object-cover shrink-0" loading="lazy" />
              <div className="min-w-0">
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground truncate">{c.category}</div>
                <div className="flex gap-3 mt-1">
                  <span className="text-sm font-bold" style={{ color: COLORS.india }}>{c.India} <span className="text-[10px] font-medium text-muted-foreground">IN</span></span>
                  <span className="text-sm font-bold" style={{ color: COLORS.usa }}>{c.USA} <span className="text-[10px] font-medium text-muted-foreground">US</span></span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { k: "Vegetarian share (India)", v: "around 55 percent", c: "var(--india)" },
          { k: "Meat anchored mains (USA)", v: "around 75 percent", c: "var(--usa)" },
          { k: "McCafé share of menu (India)", v: "27 percent", c: "#7B3F00" },
        ].map((x) => (
          <div key={x.k} className="card-elevated p-5 border-t-4" style={{ borderTopColor: x.c }}>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{x.k}</div>
            <div className="text-2xl font-bold mt-1" style={{ color: x.c }}>{x.v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
