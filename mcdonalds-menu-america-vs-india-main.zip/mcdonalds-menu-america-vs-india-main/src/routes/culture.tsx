import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, SectionCard, FlagBadge } from "@/components/dash/Primitives";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/culture")({
  head: () => ({ meta: [{ title: "Culture → Menu Mapping" }] }),
  component: Page,
});

function Chain({ country, items, color }: { country: "India" | "USA"; items: { culture: string; menu: string; outcome: string }[]; color: string }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 pb-3 border-b" style={{ borderColor: color }}>
        <FlagBadge country={country} />
        <h3 className="font-semibold">Cultural drivers → menu → nutrition outcome</h3>
      </div>
      {items.map((it, i) => (
        <div key={i} className="grid grid-cols-[1fr_auto_1fr_auto_1fr] gap-3 items-center">
          <div className="card-elevated p-3 text-sm">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Culture</div>
            <div className="font-medium">{it.culture}</div>
          </div>
          <ArrowRight className="w-4 h-4" style={{ color }} />
          <div className="card-elevated p-3 text-sm">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Menu</div>
            <div className="font-medium">{it.menu}</div>
          </div>
          <ArrowRight className="w-4 h-4" style={{ color }} />
          <div className="rounded-md p-3 text-sm text-white" style={{ background: color }}>
            <div className="text-[10px] uppercase tracking-wider text-white/80 mb-1">Outcome</div>
            <div className="font-semibold">{it.outcome}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function Page() {
  const india = [
    { culture: "Vegetarian preference around 40 percent", menu: "Paneer and aloo substitutes", outcome: "Higher fat density per vegetarian item" },
    { culture: "No beef or pork, religious constraint", menu: "Chicken only protein wall", outcome: "Reduced protein diversity" },
    { culture: "Spice forward palate", menu: "McSpicy, masala wraps", outcome: "Higher sodium baseline" },
    { culture: "Tea and coffee culture", menu: "McCafé over indexed at 27 percent", outcome: "Sugar concentrated in beverages" },
  ];
  const usa = [
    { culture: "Beef and pork are normalized", menu: "Quarter Pounder, sausage McMuffin", outcome: "Elevated cholesterol load" },
    { culture: "Protein heavy diet norm", menu: "Large chicken and beef portions", outcome: "21.6 g average protein per item" },
    { culture: "Breakfast on the go", menu: "Big Breakfast platforms", outcome: "Single meal up to 1,880 kcal" },
    { culture: "Dessert as a beverage", menu: "Shakes, frappés, McFlurry", outcome: "30.5 g average sugar per item" },
  ];

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 10 · Culture → Menu"
        title="Culture is the strongest driver of menu structure"
        subtitle="Every nutritional outcome in this dashboard is a downstream effect of a cultural input being absorbed into product design."
      />
      <SectionCard title="India · vegetarian heritage filtered through fast food economics">
        <Chain country="India" color="var(--india)" items={india} />
      </SectionCard>
      <SectionCard title="USA · meat protein abundance scaled by portion economics">
        <Chain country="USA" color="var(--usa)" items={usa} />
      </SectionCard>
    </div>
  );
}
