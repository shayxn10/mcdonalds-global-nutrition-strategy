import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, KpiCard, SectionCard } from "@/components/dash/Primitives";
import { executiveKpis } from "@/data/mcd";

export const Route = createFileRoute("/executive")({
  head: () => ({ meta: [{ title: "Executive Summary" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 12 · Executive Summary"
        title="The five numbers that define the gap"
        subtitle="A single page brief for the C suite. Each KPI is a strategic decision waiting to be made."
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {executiveKpis.map((k, i) => (
          <KpiCard key={k.label} label={k.label} value={k.value} sub={k.delta} accent={i % 2 === 0 ? "red" : "yellow"} />
        ))}
      </div>

      <SectionCard title="Bottom line read">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div className="text-[11px] uppercase tracking-wider font-semibold text-[var(--india)]">India</div>
            <p className="text-sm text-foreground/80 leading-relaxed">
              Health risk is driven by the ingredient transformation of vegetarian cuisine into high fat, high sodium fast food, with sugar heavy beverages acting as a secondary risk driver.
            </p>
          </div>
          <div className="space-y-3">
            <div className="text-[11px] uppercase tracking-wider font-semibold text-[var(--usa)]">USA</div>
            <p className="text-sm text-foreground/80 leading-relaxed">
              Health risk is structurally embedded in portion size and red meat based product design, amplified by high fat breakfast systems and dessert beverages.
            </p>
          </div>
        </div>
      </SectionCard>

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { t: "What to defend", v: "McCafé margin pool", c: "var(--mcd-yellow)" },
          { t: "What to evolve", v: "Vegetarian protein quality in India", c: "var(--india)" },
          { t: "What to monitor", v: "Sodium drift across markets", c: "var(--mcd-red)" },
        ].map(x => (
          <div key={x.t} className="card-elevated p-5 border-t-4" style={{ borderTopColor: x.c }}>
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{x.t}</div>
            <div className="text-lg font-bold mt-1">{x.v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
