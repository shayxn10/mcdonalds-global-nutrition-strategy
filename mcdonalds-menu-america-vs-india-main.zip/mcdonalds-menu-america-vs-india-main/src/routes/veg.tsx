import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { PageHeader, InsightPanel, SectionCard, FlagBadge } from "@/components/dash/Primitives";
import { vegNonveg, COLORS } from "@/data/mcd";

export const Route = createFileRoute("/veg")({
  head: () => ({ meta: [{ title: "Veg vs Non-Veg · India Deep Dive" }] }),
  component: Page,
});

function Page() {
  const [view, setView] = useState<"All" | "Veg" | "Non-Veg">("All");
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 05 · India Deep Dive"
        title="Vegetarian does not automatically mean healthier"
        subtitle="India's vegetarian majority menu carries a hidden tradeoff: lower protein efficiency, similar fat density, and sugar heavy beverages."
        right={<FlagBadge country="India" />}
      />

      <div className="flex gap-2">
        {(["All", "Veg", "Non-Veg"] as const).map((v) => (
          <button key={v} onClick={() => setView(v)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              view === v ? "bg-[var(--mcd-red)] text-white" : "bg-muted text-foreground hover:bg-muted/70"
            }`}>{v}</button>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SectionCard title="Nutrition comparison · vegetarian versus non vegetarian in India" subtitle="Average per item">
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={vegNonveg} barGap={8}>
                <CartesianGrid stroke="#eee" strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="metric" tick={{ fontSize: 11, fill: "#666" }} />
                <YAxis tick={{ fontSize: 11, fill: "#666" }} />
                <Tooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} />
                <Legend iconType="circle" />
                {(view === "All" || view === "Veg") && <Bar dataKey="Veg" fill={COLORS.green} radius={[6, 6, 0, 0]} />}
                {(view === "All" || view === "Non-Veg") && <Bar dataKey="Non-Veg" fill={COLORS.red} radius={[6, 6, 0, 0]} />}
              </BarChart>
            </ResponsiveContainer>
          </SectionCard>
        </div>
        <div className="space-y-4">
          <InsightPanel title="Protein efficiency favors non vegetarian by roughly 2 times">
            <p>Non vegetarian items deliver 17.4 g of protein versus 8.6 g in vegetarian. Paneer cannot match chicken's protein per calorie ratio.</p>
          </InsightPanel>
          <InsightPanel title="Vegetarian is not light" tone="red">
            <p>Vegetarian items still carry 14.2 g of fat. Paneer plus fried preparation closes the gap. Vegetarian sugar is also higher at 7.2 g versus 4.1 g, driven by added sauces and accompanying beverages.</p>
          </InsightPanel>
          <InsightPanel title="Data quality flag" tone="blue">
            <p>Unrealistic trans fat values surfaced during the India data cleaning step. A reminder that fast food datasets need validation before risk modeling.</p>
          </InsightPanel>
        </div>
      </div>
    </div>
  );
}
