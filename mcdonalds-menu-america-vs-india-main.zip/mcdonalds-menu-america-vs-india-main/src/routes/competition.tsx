import { createFileRoute } from "@tanstack/react-router";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { PageHeader, InsightPanel, SectionCard, FlagBadge } from "@/components/dash/Primitives";
import { marketShareIndia, marketShareUSA } from "@/data/mcd";

export const Route = createFileRoute("/competition")({
  head: () => ({ meta: [{ title: "Market & Competition · India vs USA QSR" }] }),
  component: Page,
});

function Donut({ data }: { data: typeof marketShareIndia }) {
  return (
    <ResponsiveContainer width="100%" height={320}>
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" innerRadius={70} outerRadius={120} paddingAngle={2}>
          {data.map((d, i) => <Cell key={i} fill={d.fill} />)}
        </Pie>
        <Tooltip formatter={(v: number) => `${v}%`} />
        <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}

function Page() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 02 · Market Structure"
        title="Market competition defines menu strategy"
        subtitle="India's fragmented QSR landscape forces localization. The USA's consolidated leadership enables scale driven category dominance."
      />

      <div className="grid lg:grid-cols-3 gap-6">
        <SectionCard title="India QSR is fragmented" subtitle="McDonald's holds roughly 12 percent share, pizza chains lead" action={<FlagBadge country="India" />}>
          <Donut data={marketShareIndia} />
        </SectionCard>
        <SectionCard title="USA QSR is consolidated" subtitle="McDonald's holds roughly 26 percent share as category leader" action={<FlagBadge country="USA" />}>
          <Donut data={marketShareUSA} />
        </SectionCard>
        <div className="space-y-4">
          <InsightPanel title="India is a price and localization war">
            <p>With 45 percent of the market split among regional and informal players, McDonald's competes by adapting the menu. McAloo Tikki, McSpicy Paneer, and Maharaja Mac sit at price points roughly 30 to 40 percent below the USA equivalents.</p>
          </InsightPanel>
          <InsightPanel title="USA is a scale and category dominance play" tone="blue">
            <p>McDonald's defends 26 percent share through breakfast leadership, drive thru throughput, and McCafé as a defensive flank against Starbucks. The competitive frontier is operational, not menu driven.</p>
          </InsightPanel>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="card-elevated p-6">
          <div className="text-[11px] uppercase tracking-wider text-[var(--india)] font-semibold mb-2">India implication</div>
          <h4 className="font-semibold mb-2">Menu is a localization weapon</h4>
          <p className="text-sm text-muted-foreground">A vegetarian heavy consumer base and religious constraints on beef and pork mean the global Big Mac cannot anchor the Indian menu. Paneer becomes the protein substitute, but introduces fat density tradeoffs.</p>
        </div>
        <div className="card-elevated p-6">
          <div className="text-[11px] uppercase tracking-wider text-[var(--usa)] font-semibold mb-2">USA implication</div>
          <h4 className="font-semibold mb-2">Menu is a scale margin engine</h4>
          <p className="text-sm text-muted-foreground">Beef and chicken supply chains, large format portions, and all day breakfast optimize for throughput and unit economics, which produces the calorie and sodium intensity visible across the menu.</p>
        </div>
      </div>
    </div>
  );
}
