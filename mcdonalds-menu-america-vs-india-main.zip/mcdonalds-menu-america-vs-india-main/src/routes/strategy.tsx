import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, SectionCard } from "@/components/dash/Primitives";
import { Globe2, Building2, Coffee } from "lucide-react";

export const Route = createFileRoute("/strategy")({
  head: () => ({ meta: [{ title: "Strategic Insights" }] }),
  component: Page,
});

const pillars = [
  {
    icon: Globe2,
    color: "var(--india)",
    title: "Localization in India",
    body: "A vegetarian first menu, paneer led protein, and price points roughly 30 to 40 percent below USA equivalents. The product line is functionally a different brand wearing the same arches.",
    metrics: [["55%", "Veg share of menu"], ["27%", "McCafé share"], ["+15%", "Sodium vs USA fries"]],
  },
  {
    icon: Building2,
    color: "var(--usa)",
    title: "Scale dominance in the USA",
    body: "26 percent category share defended through operational throughput, all day breakfast, large format portions, and category depth across 95 distinct main items.",
    metrics: [["26%", "QSR share"], ["95", "Main items"], ["1,880", "Top kcal item"]],
  },
  {
    icon: Coffee,
    color: "#7B3F00",
    title: "McCafé as a global margin strategy",
    body: "Beverage margins run roughly two times food margins. McCafé is the deliberate, multi market pivot toward higher margin daypart expansion and a defensive flank against Starbucks and Costa.",
    metrics: [["70 to 80%", "Beverage gross margin"], ["27% / 11%", "Menu share IN / US"], ["Hybrid", "Café platform"]],
  },
];

function Page() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Page 11 · Strategy"
        title="McDonald's adapts globally but standardizes its profitability logic"
        subtitle="Three strategic pillars hold the global system together. Different in form, identical in intent."
      />
      <div className="grid lg:grid-cols-3 gap-6">
        {pillars.map((p) => {
          const Icon = p.icon;
          return (
            <div key={p.title} className="card-elevated p-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 rounded-full opacity-10" style={{ background: p.color, transform: "translate(30%, -30%)" }} />
              <div className="w-11 h-11 rounded-lg flex items-center justify-center mb-4" style={{ background: p.color }}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-bold text-lg mb-2">{p.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed mb-5">{p.body}</p>
              <div className="grid grid-cols-3 gap-2 pt-4 border-t border-border">
                {p.metrics.map(([v, l]) => (
                  <div key={l}>
                    <div className="text-base font-bold" style={{ color: p.color }}>{v}</div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground leading-tight">{l}</div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <SectionCard title="The unifying logic">
        <div className="prose prose-sm max-w-none text-foreground/80 leading-relaxed">
          <p>The local menus look incompatible. The underlying playbook is identical. <strong>Identify the cultural anchor of food consumption, replicate it inside fast food economics, and layer a high margin beverage platform on top.</strong></p>
          <p>In India the anchor is vegetarian friendly comfort food paired with a chai equivalent coffee culture. In the USA the anchor is large format protein paired with a dessert beverage occasion. Same architecture, different inputs.</p>
        </div>
      </SectionCard>
    </div>
  );
}
