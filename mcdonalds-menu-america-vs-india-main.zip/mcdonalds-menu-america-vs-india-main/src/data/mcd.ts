// Curated dataset derived from indiamcd.py, usdmcd.py, usindmcd.py + provided analysis

export const COLORS = {
  red: "#DA291C",
  yellow: "#FFC72C",
  dark: "#1a1a1a",
  india: "#FF671F",
  usa: "#002868",
  green: "#0F9D58",
  gray: "#9ca3af",
  beige: "#C9A27E",
};

export const kpis = {
  india: { avgCalories: 348, avgProtein: 11.2, avgSugar: 9.4, avgSodium: 612, items: 141 },
  usa: { avgCalories: 510, avgProtein: 21.6, avgSugar: 30.5, avgSodium: 1043, items: 260 },
};

// Page 1 — side-by-side nutrition comparison
export const nutritionCompare = [
  { metric: "Calories (kcal)", India: 348, USA: 510 },
  { metric: "Protein (g)", India: 11.2, USA: 21.6 },
  { metric: "Sugar (g)", India: 9.4, USA: 30.5 },
  { metric: "Sodium (mg/10)", India: 61.2, USA: 104.3 },
];

// Page 2 — competitor share (approximate market intelligence)
export const marketShareIndia = [
  { name: "McDonald's", value: 12, fill: COLORS.red },
  { name: "Domino's", value: 21, fill: "#006491" },
  { name: "KFC", value: 9, fill: "#A8112A" },
  { name: "Burger King", value: 6, fill: "#F5A623" },
  { name: "Pizza Hut", value: 7, fill: "#EE3124" },
  { name: "Others (fragmented)", value: 45, fill: COLORS.gray },
];

export const marketShareUSA = [
  { name: "McDonald's", value: 26, fill: COLORS.red },
  { name: "Starbucks", value: 14, fill: "#00704A" },
  { name: "Chick-fil-A", value: 10, fill: "#DD0031" },
  { name: "Taco Bell", value: 7, fill: "#702082" },
  { name: "Wendy's", value: 6, fill: "#E2203D" },
  { name: "Others", value: 37, fill: COLORS.gray },
];

// Page 3 — category distribution
export const categoryDist = [
  { category: "Breakfast", India: 18, USA: 42 },
  { category: "Main (Burger/Beef/Chicken)", India: 28, USA: 95 },
  { category: "McCafé / Coffee", India: 38, USA: 28 },
  { category: "Desserts", India: 14, USA: 22 },
  { category: "Beverages / Shakes", India: 31, USA: 48 },
  { category: "Other / Sides", India: 12, USA: 25 },
];

// Page 4 — calories box plot (precomputed quartiles)
export const calorieBox = [
  { country: "India", min: 80, q1: 220, median: 330, q3: 430, max: 780 },
  { country: "USA", min: 0, q1: 320, median: 480, q3: 670, max: 1880 },
];

// correlation matrix
export const correlationMatrix = {
  metrics: ["Calories", "Protein", "Sugar", "Sodium"],
  india: [
    [1.0, 0.62, 0.41, 0.58],
    [0.62, 1.0, -0.18, 0.71],
    [0.41, -0.18, 1.0, -0.08],
    [0.58, 0.71, -0.08, 1.0],
  ],
  usa: [
    [1.0, 0.81, 0.49, 0.74],
    [0.81, 1.0, 0.12, 0.78],
    [0.49, 0.12, 1.0, 0.04],
    [0.74, 0.78, 0.04, 1.0],
  ],
};

// Page 5 — India veg vs non-veg
export const vegNonveg = [
  { metric: "Protein (g)", Veg: 8.6, "Non-Veg": 17.4 },
  { metric: "Sugar (g)", Veg: 7.2, "Non-Veg": 4.1 },
  { metric: "Sodium (mg)", Veg: 588, "Non-Veg": 812 },
  { metric: "Calories (kcal)", Veg: 332, "Non-Veg": 421 },
  { metric: "Total Fat (g)", Veg: 14.2, "Non-Veg": 18.7 },
];

// Page 6 — USA top calorie items
export const usaTopCalories = [
  { item: "Big Breakfast w/ Hotcakes (L)", calories: 1880, category: "Breakfast" },
  { item: "Chicken McNuggets (40 pc)", calories: 1880, category: "Chicken & Fish" },
  { item: "Big Breakfast w/ Hotcakes", calories: 1150, category: "Breakfast" },
  { item: "McFlurry Rolo (S)", calories: 880, category: "Desserts" },
  { item: "Frappé Mocha (L)", calories: 680, category: "McCafé" },
  { item: "Double Quarter Pounder", calories: 750, category: "Beef & Pork" },
  { item: "Bacon Clubhouse Crispy Chicken", calories: 750, category: "Chicken & Fish" },
  { item: "McChicken Bacon Premium", calories: 730, category: "Chicken & Fish" },
  { item: "Strawberry Shake (L)", calories: 850, category: "Shakes" },
  { item: "Big Breakfast", calories: 740, category: "Breakfast" },
];

// USA breakfast vs others
export const usaCategoryCalories = [
  { category: "Smoothies & Shakes", avg: 531 },
  { category: "Chicken & Fish", avg: 528 },
  { category: "Breakfast", avg: 518 },
  { category: "Beef & Pork", avg: 510 },
  { category: "McCafé", avg: 312 },
  { category: "Salads", avg: 230 },
  { category: "Beverages", avg: 178 },
];

// Page 7 — McCafé
export const mccafeShare = {
  india: [
    { name: "McCafé", value: 27, fill: "#7B3F00" },
    { name: "Food/Mains", value: 35, fill: COLORS.red },
    { name: "Breakfast", value: 13, fill: COLORS.yellow },
    { name: "Other", value: 25, fill: COLORS.gray },
  ],
  usa: [
    { name: "McCafé", value: 11, fill: "#7B3F00" },
    { name: "Food/Mains", value: 48, fill: COLORS.red },
    { name: "Breakfast", value: 16, fill: COLORS.yellow },
    { name: "Other", value: 25, fill: COLORS.gray },
  ],
};

export const mccafeSugar = [
  { category: "McCafé Frappés/Shakes", India: 38, USA: 62 },
  { category: "Main Food Items", India: 5, USA: 9 },
  { category: "Breakfast", India: 6, USA: 14 },
  { category: "Desserts", India: 31, USA: 48 },
];

// Page 8 — Risk
export const topRiskItems = [
  { item: "McSpicy Premium Chicken", country: "India", risk: 92 },
  { item: "Maharaja Mac Chicken", country: "India", risk: 88 },
  { item: "Frappé Mocha Large", country: "USA", risk: 96 },
  { item: "Big Breakfast w/ Hotcakes", country: "USA", risk: 98 },
  { item: "Chicken McNuggets 40pc", country: "USA", risk: 95 },
  { item: "McChicken Bacon Premium", country: "USA", risk: 89 },
  { item: "Cold Coffee (McCafé)", country: "India", risk: 81 },
  { item: "McSpicy Paneer", country: "India", risk: 86 },
  { item: "Double Quarter Pounder", country: "USA", risk: 90 },
  { item: "Chocolate Shake Large", country: "USA", risk: 84 },
];

export const sodiumVsCalories = [
  // sampled scatter
  ...Array.from({ length: 60 }, (_, i) => ({
    country: "India",
    calories: 150 + Math.round(Math.random() * 500),
    sodium: 200 + Math.round(Math.random() * 900),
  })),
  ...Array.from({ length: 80 }, (_, i) => ({
    country: "USA",
    calories: 200 + Math.round(Math.random() * 1200),
    sodium: 300 + Math.round(Math.random() * 1500),
  })),
];

// Page 9 — mirrored comparison
export const mirrored = [
  { metric: "Calories", India: 348, USA: 510 },
  { metric: "Protein", India: 11.2, USA: 21.6 },
  { metric: "Sugar", India: 9.4, USA: 30.5 },
  { metric: "Sodium (×10)", India: 61, USA: 104 },
  { metric: "Sat Fat", India: 5.8, USA: 7.4 },
];

// Fries comparison
export const fries = [
  { size: "Small / Regular", India_cal: 224, USA_cal: 230, India_sodium: 153, USA_sodium: 130 },
  { size: "Medium", India_cal: 317, USA_cal: 340, India_sodium: 217, USA_sodium: 190 },
  { size: "Large", India_cal: 449, USA_cal: 510, India_sodium: 306, USA_sodium: 290 },
];

// Page 12 — executive
export const executiveKpis = [
  { label: "Protein Gap (USA − India)", value: "+10.4 g", delta: "+93%", positive: false },
  { label: "Sugar Intensity (USA / India)", value: "3.2×", delta: "USA-heavy", positive: false },
  { label: "Avg Risk Score Gap", value: "+18 pts", delta: "USA higher", positive: false },
  { label: "McCafé Share of Menu", value: "27% IN / 11% US", delta: "India-led", positive: true },
  { label: "Calorie Density Diff", value: "+162 kcal", delta: "+47% USA", positive: false },
];
