import type { ReactNode } from "react";

export function PageHeader({
  eyebrow, title, subtitle, right,
}: { eyebrow: string; title: string; subtitle?: string; right?: ReactNode }) {
  return (
    <div className="flex items-end justify-between gap-6 mb-8 pb-6 border-b border-border">
      <div>
        <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[var(--mcd-red)] mb-2">{eyebrow}</div>
        <h1 className="text-3xl md:text-4xl font-bold text-foreground max-w-3xl leading-tight">{title}</h1>
        {subtitle && <p className="mt-3 text-muted-foreground max-w-2xl">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

export function KpiCard({
  label, value, sub, accent,
}: { label: string; value: string; sub?: string; accent?: "red" | "yellow" | "india" | "usa" | "neutral" }) {
  const accentMap: Record<string, string> = {
    red: "var(--mcd-red)",
    yellow: "var(--mcd-yellow)",
    india: "var(--india)",
    usa: "var(--usa)",
    neutral: "var(--muted-foreground)",
  };
  const c = accentMap[accent ?? "neutral"];
  return (
    <div className="card-elevated p-5 relative overflow-hidden">
      <div className="absolute left-0 top-0 bottom-0 w-1" style={{ background: c }} />
      <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-2 text-3xl font-bold text-foreground tabular-nums">{value}</div>
      {sub && <div className="mt-1 text-xs text-muted-foreground">{sub}</div>}
    </div>
  );
}

export function InsightPanel({
  title, children, tone = "default",
}: { title: string; children: ReactNode; tone?: "default" | "red" | "blue" }) {
  const toneCls =
    tone === "red"
      ? "bg-[#FFF5F4] border-l-4 border-[var(--mcd-red)]"
      : tone === "blue"
      ? "bg-[#F0F6FF] border-l-4 border-[var(--usa)]"
      : "insight-panel";
  return (
    <div className={`${toneCls} p-5 rounded-md`}>
      <div className="flex items-center gap-2 mb-2">
        <span className="text-[10px] font-bold uppercase tracking-[0.18em] text-foreground/70">So What</span>
        <span className="h-px flex-1 bg-foreground/10" />
      </div>
      <h3 className="font-semibold text-foreground mb-2">{title}</h3>
      <div className="text-sm text-foreground/75 leading-relaxed space-y-2">{children}</div>
    </div>
  );
}

export function SectionCard({
  title, subtitle, children, action,
}: { title: string; subtitle?: string; children: ReactNode; action?: ReactNode }) {
  return (
    <div className="card-elevated p-6">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-semibold text-foreground">{title}</h3>
          {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </div>
  );
}

export function FlagBadge({ country }: { country: "India" | "USA" }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold text-white"
      style={{ background: country === "India" ? "var(--india)" : "var(--usa)" }}
    >
      {country === "India" ? "🇮🇳" : "🇺🇸"} {country}
    </span>
  );
}
