import { Link, useRouterState } from "@tanstack/react-router";
import {
  BarChart3, Globe2, Building2, Layers, Activity, Leaf, Flame,
  Coffee, ShieldAlert, GitCompareArrows, Map, Lightbulb, FileBarChart, Trophy,
} from "lucide-react";
import logo from "@/assets/mcd-logo.png";

const nav = [
  { to: "/", label: "Global Overview", icon: Globe2, num: "01" },
  { to: "/competition", label: "Market & Competition", icon: Building2, num: "02" },
  { to: "/menu", label: "Menu Composition", icon: Layers, num: "03" },
  { to: "/nutrition", label: "Nutrition Architecture", icon: Activity, num: "04" },
  { to: "/veg", label: "Veg vs Non-Veg (India)", icon: Leaf, num: "05" },
  { to: "/usa-intensity", label: "USA Menu Intensity", icon: Flame, num: "06" },
  { to: "/mccafe", label: "McCafé Strategic Layer", icon: Coffee, num: "07" },
  { to: "/risk", label: "Risk & Health", icon: ShieldAlert, num: "08" },
  { to: "/comparison", label: "Cross-Country", icon: GitCompareArrows, num: "09" },
  { to: "/culture", label: "Culture → Menu", icon: Map, num: "10" },
  { to: "/strategy", label: "Strategic Insights", icon: Lightbulb, num: "11" },
  { to: "/executive", label: "Executive Summary", icon: FileBarChart, num: "12" },
  { to: "/conclusion", label: "Final Conclusion", icon: Trophy, num: "13" },
] as const;

export function Sidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <aside className="w-72 shrink-0 bg-sidebar text-sidebar-foreground border-r border-sidebar-border min-h-screen sticky top-0 flex flex-col">
      <div className="p-6 border-b border-sidebar-border flex items-center gap-3">
        <div className="w-11 h-11 rounded-lg bg-[var(--mcd-red)] flex items-center justify-center shadow-lg">
          <img src={logo} alt="" width={28} height={28} className="object-contain" />
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-[0.18em] text-sidebar-foreground/60">McDonald's</div>
          <div className="text-sm font-semibold leading-tight">Global Nutrition<br/>& Strategy</div>
        </div>
      </div>
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {nav.map((n) => {
          const active = pathname === n.to;
          const Icon = n.icon;
          return (
            <Link
              key={n.to}
              to={n.to}
              className={`group flex items-center gap-3 px-3 py-2.5 rounded-md text-[13px] transition-colors ${
                active
                  ? "bg-[var(--mcd-red)] text-white font-semibold shadow-md"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
              }`}
            >
              <span className={`text-[10px] font-mono ${active ? "text-white/80" : "text-sidebar-foreground/40"}`}>{n.num}</span>
              <Icon className="w-4 h-4 shrink-0" />
              <span className="truncate">{n.label}</span>
            </Link>
          );
        })}
      </nav>
      <div className="p-4 border-t border-sidebar-border text-[10px] text-sidebar-foreground/50 leading-relaxed">
        Consulting-grade analytics<br/>India vs USA · 2024
      </div>
    </aside>
  );
}
